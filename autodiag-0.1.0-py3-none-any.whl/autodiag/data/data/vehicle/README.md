# countries.tsv
ISO3780 for the definition codes to country_name
ISO 3166-1 for alpha3 code
# manufacturers.tsv
ISO3780