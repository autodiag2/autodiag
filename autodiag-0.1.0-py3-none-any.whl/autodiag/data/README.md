
Database of cars and engines used by autodiag.  
It also includes a VIN decoder.

# Add a new car to the database
```bash
./scripts/newCarDescription.sh
```

# Decode VIN
See scripts/VIN/README.md